sap.ui.define([
	"studend00sap.education./project1/test/unit/controller/main.controller"
], function () {
	"use strict";
});
